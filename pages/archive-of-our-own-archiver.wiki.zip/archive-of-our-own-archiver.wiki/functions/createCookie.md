[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / createCookie

# Function: createCookie()

> **createCookie**(`cookie`): `Promise`\<`unknown`\>

## Parameters

• **cookie**: `Cookie`

## Returns

`Promise`\<`unknown`\>

## Defined in

[chrome-services/utils/cookies.ts:17](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/utils/cookies.ts#L17)
