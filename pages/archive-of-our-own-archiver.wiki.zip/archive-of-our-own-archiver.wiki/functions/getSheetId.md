[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / getSheetId

# Function: getSheetId()

> **getSheetId**(`spreadsheetUrl`, `authToken`): `Promise`\<`any`\>

## Parameters

• **spreadsheetUrl**: `string`

• **authToken**: `string`

## Returns

`Promise`\<`any`\>

## Defined in

[chrome-services/utils/getSheetId.tsx:5](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/utils/getSheetId.tsx#L5)
