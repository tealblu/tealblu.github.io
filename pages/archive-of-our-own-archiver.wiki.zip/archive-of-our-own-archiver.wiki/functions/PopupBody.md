[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / PopupBody

# Function: PopupBody()

> **PopupBody**(): `Element`

## Returns

`Element`

## Defined in

[components/popup\_body.tsx:7](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/components/popup_body.tsx#L7)
