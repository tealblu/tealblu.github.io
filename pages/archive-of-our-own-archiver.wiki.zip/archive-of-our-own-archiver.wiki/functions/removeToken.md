[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / removeToken

# Function: removeToken()

> **removeToken**(): `Promise`\<`void`\>

## Returns

`Promise`\<`void`\>

## Defined in

[chrome-services/accessToken.tsx:44](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/accessToken.tsx#L44)
