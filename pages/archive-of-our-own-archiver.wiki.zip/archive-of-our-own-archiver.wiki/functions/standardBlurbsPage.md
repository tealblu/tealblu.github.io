[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / standardBlurbsPage

# Function: standardBlurbsPage()

> **standardBlurbsPage**(`port`): `void`

## Parameters

• **port**: `Port`

## Returns

`void`

## Defined in

[pages/blurbsPage.tsx:8](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/pages/blurbsPage.tsx#L8)
