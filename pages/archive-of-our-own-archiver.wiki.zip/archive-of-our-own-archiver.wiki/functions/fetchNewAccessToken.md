[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / fetchNewAccessToken

# Function: fetchNewAccessToken()

> **fetchNewAccessToken**(`interactive`?): `Promise`\<`string`\>

get token from identity API

## Parameters

• **interactive?**: `boolean`

true if you want to ask the user for permission to access their google account

## Returns

`Promise`\<`string`\>

token or empty string

## Defined in

[chrome-services/accessToken.tsx:11](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/accessToken.tsx#L11)
