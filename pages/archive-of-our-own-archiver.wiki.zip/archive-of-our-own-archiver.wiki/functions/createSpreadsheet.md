[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / createSpreadsheet

# Function: createSpreadsheet()

> **createSpreadsheet**(`token`): `Promise`\<`any`\>

## Parameters

• **token**: `string`

user's auth token

## Returns

`Promise`\<`any`\>

## Defined in

[chrome-services/spreadsheet.tsx:47](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/spreadsheet.tsx#L47)
