[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / addWorkToSheet

# Function: addWorkToSheet()

> **addWorkToSheet**(`spreadsheetUrl`, `authToken`, `work`): `Promise`\<`any`\>

## Parameters

• **spreadsheetUrl**: `string`

• **authToken**: `string`

• **work**: `BaseWork`

## Returns

`Promise`\<`any`\>

## Defined in

[chrome-services/utils/addWorkToSheet.tsx:6](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/utils/addWorkToSheet.tsx#L6)
