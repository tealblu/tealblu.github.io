[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / getCookie

# Function: getCookie()

> **getCookie**(`cookieName`, `url`): `Promise`\<`unknown`\>

## Parameters

• **cookieName**: `string`

• **url**: `string`

## Returns

`Promise`\<`unknown`\>

## Defined in

[chrome-services/utils/cookies.ts:28](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/utils/cookies.ts#L28)
