[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / Logout

# Function: Logout()

> **Logout**(): `Element`

## Returns

`Element`

## Defined in

[components/Logout.tsx:4](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/components/Logout.tsx#L4)
