[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / fetchSpreadsheetUrl

# Function: fetchSpreadsheetUrl()

> **fetchSpreadsheetUrl**(): `Promise`\<`string`\>

## Returns

`Promise`\<`string`\>

user's spreadsheet URL

## Defined in

[chrome-services/spreadsheet.tsx:8](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/spreadsheet.tsx#L8)
