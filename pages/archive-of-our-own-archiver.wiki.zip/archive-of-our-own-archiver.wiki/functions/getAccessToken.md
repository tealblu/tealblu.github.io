[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / getAccessToken

# Function: getAccessToken()

> **getAccessToken**(): `Promise`\<`string`\>

Retrieves the access token from a cookie.

## Returns

`Promise`\<`string`\>

A promise that resolves to the access token string.

## Throws

An error if the access token cannot be retrieved.

## Defined in

[chrome-services/accessToken.tsx:65](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/chrome-services/accessToken.tsx#L65)
