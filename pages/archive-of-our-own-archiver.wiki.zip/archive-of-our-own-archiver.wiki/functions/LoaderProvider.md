[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / LoaderProvider

# Function: LoaderProvider()

> **LoaderProvider**(`__namedParameters`): `Element`

## Parameters

• **\_\_namedParameters**: [`PropsWithChildren`](../type-aliases/PropsWithChildren.md)

## Returns

`Element`

## Defined in

[contexts/LoaderContext.tsx:14](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/contexts/LoaderContext.tsx#L14)
