[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / PropsWithChildren

# Type Alias: PropsWithChildren

> **PropsWithChildren**: `object`

## Type declaration

### children

> **children**: `JSX.Element` \| `JSX.Element`[]

## Defined in

[types/PropsWithChildren.d.ts:1](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/types/PropsWithChildren.d.ts#L1)
