[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / TokenState

# Type Alias: TokenState

> **TokenState**: `object`

The TokenState type in TypeScript represents an object with accessToken and refreshToken properties
that can be either strings or null.

## Type declaration

### accessToken

> **accessToken**: `string` \| `null`

### refreshToken

> **refreshToken**: `string` \| `null`

## Defined in

[store/tokenSlice.ts:13](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/store/tokenSlice.ts#L13)
