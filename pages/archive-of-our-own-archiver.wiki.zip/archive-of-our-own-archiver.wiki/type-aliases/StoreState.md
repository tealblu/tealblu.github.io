[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / StoreState

# Type Alias: StoreState

> **StoreState**: `object`

## Defined in

[store/index.ts:3](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/store/index.ts#L3)
