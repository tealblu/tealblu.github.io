[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / User

# Interface: User

## Properties

### authToken

> **authToken**: `string`

#### Defined in

[types/user.d.ts:7](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/types/user.d.ts#L7)

***

### sheetId?

> `optional` **sheetId**: `string`

#### Defined in

[types/user.d.ts:8](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/types/user.d.ts#L8)

***

### sheetUrl?

> `optional` **sheetUrl**: `string`

#### Defined in

[types/user.d.ts:9](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/types/user.d.ts#L9)
