[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / TokenSliceInterface

# Interface: TokenSliceInterface

## Properties

### accessToken

> **accessToken**: `null` \| `string`

#### Defined in

[store/tokenSlice.ts:22](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/store/tokenSlice.ts#L22)

***

### refreshToken

> **refreshToken**: `null` \| `string`

#### Defined in

[store/tokenSlice.ts:23](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/store/tokenSlice.ts#L23)

***

### setAccessToken()

> **setAccessToken**: (`accessToken`) => `void`

#### Parameters

• **accessToken**: `string`

#### Returns

`void`

#### Defined in

[store/tokenSlice.ts:24](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/store/tokenSlice.ts#L24)

***

### setRefreshToken()

> **setRefreshToken**: (`refreshToken`) => `void`

#### Parameters

• **refreshToken**: `string`

#### Returns

`void`

#### Defined in

[store/tokenSlice.ts:25](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/store/tokenSlice.ts#L25)
