[**Archive of Our Own Archiver**](../README.md) • **Docs**

***

[Archive of Our Own Archiver](../README.md) / TokenContext

# Variable: TokenContext

> `const` **TokenContext**: `Context`\<`object`\>

## Type declaration

### authToken

> **authToken**: `string` = `''`

### setAuthToken()

> **setAuthToken**: (`authToken`) => `void`

#### Parameters

• **authToken**: `string`

#### Returns

`void`

## Defined in

[contexts/TokenContext.tsx:4](https://github.com/shaineoneal/final_extension/blob/f7c9137fded305d80f1917c9f6183237368e43ac/src/contexts/TokenContext.tsx#L4)
