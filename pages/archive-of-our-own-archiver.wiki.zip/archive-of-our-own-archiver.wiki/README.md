**Archive of Our Own Archiver** • **Docs**

***

# Archive of Our Own Archiver

## Interfaces

- [TokenSliceInterface](interfaces/TokenSliceInterface.md)
- [User](interfaces/User.md)

## Type Aliases

- [LoaderStateType](type-aliases/LoaderStateType.md)
- [StoreState](type-aliases/StoreState.md)
- [TokenState](type-aliases/TokenState.md)
- [PropsWithChildren](type-aliases/PropsWithChildren.md)
- [UserStateType](type-aliases/UserStateType.md)

## Variables

- [LoaderContext](variables/LoaderContext.md)
- [TokenContext](variables/TokenContext.md)

## Functions

- [fetchNewAccessToken](functions/fetchNewAccessToken.md)
- [removeToken](functions/removeToken.md)
- [getAccessToken](functions/getAccessToken.md)
- [isAccessTokenValid](functions/isAccessTokenValid.md)
- [fetchSpreadsheetUrl](functions/fetchSpreadsheetUrl.md)
- [createSpreadsheet](functions/createSpreadsheet.md)
- [addWorkToSheet](functions/addWorkToSheet.md)
- [createCookie](functions/createCookie.md)
- [getCookie](functions/getCookie.md)
- [getSheetId](functions/getSheetId.md)
- [GoToSheet](functions/GoToSheet.md)
- [Login](functions/Login.md)
- [Logout](functions/Logout.md)
- [NewSheet](functions/NewSheet.md)
- [OptionsIcon](functions/OptionsIcon.md)
- [PopupBody](functions/PopupBody.md)
- [LoaderProvider](functions/LoaderProvider.md)
- [TokenProvider](functions/TokenProvider.md)
- [standardBlurbsPage](functions/standardBlurbsPage.md)
- [wrap](functions/wrap.md)
