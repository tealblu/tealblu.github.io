---
date: 2024-06-30
category: blog
keywords: interstitial journaling, digital garden
title: Interstitial Journaling
tags:
categories: blog
lastMod: 2025-02-14
---
work in progress
