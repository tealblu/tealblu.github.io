---
date: 2024-06-30
category: blog
keywords: interstitial journaling, digital garden
title: Interstitial Journaling
tags:
categories: blog
lastMod: 2024-06-30
---
work in progress
