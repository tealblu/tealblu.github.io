---
date: 2024-06-30
category: list, blog
keywords: reading, reading list
image: "../assets/image_1719791058658_0.png"
title: Reading List
tags:
categories: list, blog
lastMod: 2025-02-14
---
Since I'm getting more into reading these days, I thought it might be interesting to share my reading list.



# in progress

| cover | title | rating | link to review |
| :-------------- | :-------------- | :-------------- | :-- | :-------------- |
| ![image.png](/assets/image_1719791058658_0.png) | [Fuzzy Logic](https://books.google.com/books/about/Fuzzy_Logic.html?id=CM1SAAAAMAAJ) | n/a | n/a |

# completed

| cover | title | rating | link to review |

# upcoming

| cover | title | rating | link to review |
