---
date: 2024-01-20
category: meta
keywords: development, templates
title: Templates
tags:
categories: meta
lastMod: 2024-01-21
---
metadata
template:: metadata
template-including-parent:: false

  + date:: YYYY-MM-DD
category::
keywords::
public:: true
