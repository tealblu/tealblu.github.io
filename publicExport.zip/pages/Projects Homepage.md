---
date: 2024-01-20
category: projects
keywords: projects, my projects, code, diy, root
title: Projects Homepage
tags:
categories: projects
lastMod: 2025-02-14
---
### What kind of projects do I do?
I'm interested in a lot of different stuff! This collection will hopefully become an archive of my various projects, both for my personal reference and to document for future employment purposes. The types of projects here will include:

  + Code, programming, and related projects -> [Code Projects]({{< ref "/pages/Code Projects" >}})

  + DIY stuff

  + Music

  + And potentially more...
