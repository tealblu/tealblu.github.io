---
date: 2024-01-21
keywords: ai, topside, stratus vision, bosch
title: Image Classification AI
tags:
categories:
lastMod: 2025-02-14
---
I created an AI for automated classification of production line quality control images on Stratus Vision AOI systems. I identified key areas of application and improvement, and performed ongoing fine-tuning and maintenance to the model based on various metrics.
