---
date: 2024-01-21
category: projects
keywords: projects, code, coding
title: My Projects/Code
tags:
categories: projects
lastMod: 2024-01-21
---
### Description:
This is the collection of my code projects that I've done over the years.

### Project List:

  + PDP-11 Instruction Set Simulator: [My Projects/Code/pdp11-sim]({{< ref "/pages/My Projects/Code/pdp11-sim" >}})

  + DriveTime: [My Projects/Code/DriveTime]({{< ref "/pages/My Projects/Code/DriveTime" >}})

  + Image Classification AI: [My Projects/Code/Image Classification AI]({{< ref "/pages/My Projects/Code/Image Classification AI" >}})

  + Low-Cost Universal Camera Array: [My Projects/Code/LUCA]({{< ref "/pages/My Projects/Code/LUCA" >}})

  + Archive website (the website you're on)
