---
date: 2024-01-21
keywords: code, drivetime, c#, school
title: My Projects/Code/DriveTime
tags:
categories:
lastMod: 2024-01-21
---
DriveTime is a web application intended to incentivize truck drivers to drive more safely. It is built with C#, CSHMTL, Entity Framework Core, Ebay API, iTunes API, AWS Elastic Beanstalk, AWS EC2, and AWS RDS.
