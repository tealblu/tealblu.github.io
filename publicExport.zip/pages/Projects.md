---
cdate:
- Oct 8th, 2023
date:
- Oct 8th, 2023
title: Projects
tags:
categories:
lastMod: 2024-01-19
---
Project list

  + [Projects/Home Assistant]({{< ref "/pages/Projects/Home Assistant" >}})

    + [Projects/Home Assistant/Notify]({{< ref "/pages/Projects/Home Assistant/Notify" >}})

    + [Projects/Home Assistant/Remove TV Display From Shaine's PC]({{< ref "/pages/Projects/Home Assistant/Remove TV Display From Shaine's PC" >}})

  + Projects/Code
