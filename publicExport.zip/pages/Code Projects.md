---
date: 2024-01-21
category: projects
keywords: projects, code, coding
title: Code Projects
tags:
categories: projects
lastMod: 2025-02-14
---
### Description:
This is the collection of my code projects that I've done over the years.

### Project List:

  + PDP-11 Instruction Set Simulator: [PDP-11 Instruction Set Simulator]({{< ref "/pages/PDP-11 Instruction Set Simulator" >}})

  + DriveTime: [DriveTime]({{< ref "/pages/DriveTime" >}})

  + Image Classification AI: [Image Classification AI]({{< ref "/pages/Image Classification AI" >}})

  + Low-Cost Universal Camera Array: [LUCA]({{< ref "/pages/LUCA" >}})

  + Archive website (the website you're on)

    + Homepage graph view: [Graph Rendering]({{< ref "/pages/Graph Rendering" >}})
