---
title: Projects/Home Assistant
tags:
categories:
date: 2023-12-28
lastMod: 2023-12-28
---
metadata


  + date:: Oct 8th, 2023 
tags:: #Projects

This is the central topic for all Home Assistant, HASS, and home automation pages

Sub-projects

  + [Projects/Home Assistant/Notify]({{< ref "/pages/Projects/Home Assistant/Notify" >}})

  + [Projects/Home Assistant/OpenAI Integration]({{< ref "/pages/Projects/Home Assistant/OpenAI Integration" >}})

Themes


  + **19:34** quick capture:  [iOS Dark Mode Theme - Share your Projects! / Themes - Home Assistant Community](https://community.home-assistant.io/t/ios-dark-mode-theme/149136)

  + **19:35** quick capture:  [Google Dark Theme -- JuanMTech - Share your Projects! / Themes - Home Assistant Community](https://community.home-assistant.io/t/google-dark-theme-juanmtech/164225)

    + I think this is the one that I want
