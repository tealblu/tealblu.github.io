---
date:
- Nov 26th, 2023
tags:
- Projects
title: Projects/Code/USB Port Sleeper
categories:
lastMod: 2023-12-28
---
I want the light on shaine's computer to go to sleep after a period of inactivity

  + Alt. I could connect the light to home assistant??

    + How to communicate with home assistant??

**11:12** quick capture:  [REST API | Home Assistant Developer Docs](https://developers.home-assistant.io/docs/api/rest)

    + API Ref:
|Command|Action|
|--|--|
|sdusb_off|Turn Shaine's USB Port off|
|sdusb_on|Turn Shaine's USB Port on|
